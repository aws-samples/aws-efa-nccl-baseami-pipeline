#!/bin/bash

get_gateway() {
	gateway=$(ipcalc $1 | grep HostMin | awk '{print $2}')
        echo $gateway
}

m=-1
for NET in $(sudo lshw -C network | grep -i logical | awk '{print $3}' | grep -v docker0)
do 
  m=$((m+1))
  export NIC$m=$NET
done

m=-1
for MACS in $(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/)
do
  m=$((m+1))
  export MAC$m=$MACS
  CIDR=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MACS/subnet-ipv4-cidr-block)

  export GATEWAY$m=$(get_gateway $CIDR)
  IPV4=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MACS/local-ipv4s)
  export IPV4$m=$IPV4

done

m=-1
for MACS in $(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/)
do
  m=$((m+1))
  n="NIC$m"
  a="MAC$m"
  b="IPV4$m"
  c="GATEWAY$m"
  cat << EOF > /tmp/5$m-${!n}.yaml
network:
  version: 2
  renderer: networkd
  ethernets:
    ${!n}:
      dhcp4: yes
      dhcp4-overrides:
        use-routes: false
      match:
        macaddress: ${!a::-1}
      mtu: "9001"
      routes:
       - to: 0.0.0.0/0
         via: ${!c} # Default gateway
         table: 100$m
      routing-policy:
        - from: ${!b}
          table: 100$m
EOF
  if [ $m -ge 1 ]; then
    sudo cp /tmp/5$m-${!n}.yaml /etc/netplan
  fi
done

cat << EOF > /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks
#!/bin/bash

EOF

m=-1
for MACS in $(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/)
do
  m=$((m+1))
  n="NIC$m"
  a="MAC$m"
  b="IPV4$m"
  c="GATEWAY$m"
  CIDR=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MACS/subnet-ipv4-cidr-block)
  if [ $m -ge 1 ]; then
    echo -e "/sbin/ip route del $CIDR dev ${!n} proto kernel scope link src ${!b}" |  tee -a /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks
  fi
done

chmod +x /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks

netplan --debug apply

sleep 5

dhclient -v
