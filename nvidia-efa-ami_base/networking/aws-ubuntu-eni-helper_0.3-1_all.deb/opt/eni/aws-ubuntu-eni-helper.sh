#!/bin/bash

get_gateway() {
        gateway=$(ipcalc $1 | grep HostMin | awk '{print $2}')
        echo $gateway
}

ACTIVE_NIC=$(ip a | grep UP | grep 9001 | awk '{print $2}' | tr -d '\:' | wc -l)
export PRINIC=$(ip a | grep UP | grep 9001 | awk '{print $2}' | tr -d '\:')
ACTIVE_PLAN=$(ls /etc/netplan | wc -l)

if [ $ACTIVE_PLAN -ge 2 ]; then
   echo "Multiple EFA NICS detected. Not changing netplan and exiting"
   exit 0
fi

cat << EOF > /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks
#!/bin/bash

EOF

m=-1
for ENI in $(find /sys/class/net -mindepth 1 -maxdepth 1 ! -name lo ! -name docker0 -printf "%P: " -execdir cat {}/address \; | awk '{print $1}' | tr -d '\:')
do
  m=$((m+1))
  export NIC$m=$ENI
done


m=-1
for MACS in $(find /sys/class/net -mindepth 1 -maxdepth 1 ! -name lo ! -name docker0 -printf "%P: " -execdir cat {}/address \; | awk '{print $2}')
do
  m=$((m+1))
  export MAC$m=$MACS
  CIDR=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MACS/subnet-ipv4-cidr-block)

  export GATEWAY$m=$(get_gateway $CIDR)
  IPV4=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MACS/local-ipv4s)
  export IPV4$m=$IPV4

  n="NIC$m"
  a="MAC$m"
  b="IPV4$m"
  c="GATEWAY$m"
  cat << EOF > /tmp/6$m-${!n}.yaml
network:
  version: 2
  renderer: networkd
  ethernets:
    ${!n}:
      dhcp4: yes
      dhcp4-overrides:
        use-routes: true
      match:
        macaddress: ${!a}
      mtu: "9001"
      routes:
       - to: 0.0.0.0/0
         via: ${!c} # Default gateway
         table: 100$m
      routing-policy:
        - from: ${!b}
          table: 100$m
EOF
  if [[ "${!n}" != "$PRINIC" ]]; then
    sudo mv /tmp/6$m-${!n}.yaml /etc/netplan
    echo -e "/sbin/ip route del $CIDR dev ${!n} proto kernel scope link src ${!b}" |  tee -a /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks
  fi
done

chmod +x /usr/lib/networkd-dispatcher/routable.d/50-ifup-hooks

netplan --debug apply
